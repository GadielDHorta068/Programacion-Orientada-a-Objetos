package org.deneb.parcial1.modelo;

public class PersonaRepetidaException extends Throwable{
}
